package PageObjects;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LogInPage {
	
	private static WebElement element = null;
	
	public static WebElement username(WebDriver driver)
	{
		element = driver.findElement(By.id("emailAddress"));
		 
		return element;
	}

	public static WebElement password(WebDriver driver)
	{
		element = driver.findElement(By.id("password"));
		
		return element;
	}
	
	public static WebElement Login(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id=\"credentials\"]/fieldset/div[3]/button"));
		
		return element;
	}
}
