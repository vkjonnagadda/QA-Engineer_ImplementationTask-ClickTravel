package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
	
private static WebElement element = null;
	
	public static WebElement pageHeading(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id=\'page-heading\']"));
		 
		return element;
	}
	

}
