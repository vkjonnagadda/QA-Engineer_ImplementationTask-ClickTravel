package LogIn;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.HomePage;
import PageObjects.LogInPage;
import junit.framework.Test;

public class Successful_LogIn {
	
	//Login to travel cloud successfully and assure User is able to view the dashboard
	//Apologies, I had to put hard coded wait as there is not much time to write a function for wait
	public static void main(String[] args) throws InterruptedException 
	{		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\jonnagaddav\\Documents\\Selenium Installations\\ChromeDriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://apps-preview.uat.travel.cloud");
	//	driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		Thread.sleep(3000);
		LogInPage.username(driver).sendKeys("qualityassurance@clicktravel.com");;
		LogInPage.password(driver).sendKeys("Testing123");;
		LogInPage.Login(driver).click();
	//	driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		Thread.sleep(3000);
		if(driver.getPageSource().contains("Hello Quality"))
		{
			System.out.println("Login is Successful, User is able to view the dashboard");
		}
		else
		{
			System.out.println("Login is UnSuccessful");
		}
		
		driver.quit();
	}
	
}
